======================================================================
TESTING PART B
======================================================================

Tests are available in the test_part_*_*.in files.

To test your implementation for correctness, please run
    python solution_template.py

For each test case a CORRECT ANSWER or WRONG ANSWER message will be displayed along with
the running time for the respective test case.

For reference, here is the output for the official solution with the running times:

RUNNING TESTS

Running test 1 for part A:
Your solution took 0.000226020812988 seconds
CORRECT ANSWER

Running test 2 for part A:
Your solution took 0.000493049621582 seconds
CORRECT ANSWER

Running test 1 for part B:
Your solution took 0.000489950180054 seconds
CORRECT ANSWER

Running test 2 for part B:
Your solution took 0.195070028305 seconds
CORRECT ANSWER

Running test 1 for part C:
Your solution took 0.000572919845581 seconds
CORRECT ANSWER

Running test 2 for part C:
Your solution took 0.126935958862 seconds
CORRECT ANSWER

Running test 1 for part D:
Your solution took 0.000877857208252 seconds
CORRECT ANSWER

Running test 2 for part D:
Your solution took 0.353004932404 seconds
CORRECT ANSWER

EVERTHING CORRECT
